let lebarLingkaran = 50;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  circle(30, 30, lebarLingkaran);
  circle(30, 70, lebarLingkaran);
  circle(70, 110, lebarLingkaran);
  circle(110, 150, lebarLingkaran);
} 
