function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  lingkaran();
}

function lingkaran() {
  fill(225,255,0);
  strokeWeight(5);
  circle(200,200,100);
}